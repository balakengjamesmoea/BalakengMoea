
  const contactForm = document.getElementById('contactForm');
  const formStatus = document.getElementById('formStatus');
  const submitButton = contactForm.querySelector('button[type="submit"]');

  contactForm.addEventListener('submit', async function (event) {
    event.preventDefault();

    // Basic browser validation
    if (!contactForm.checkValidity()) {
      contactForm.classList.add('was-validated');
      showStatus('Please complete all required fields correctly.', 'error');
      return;
    }

    const originalButtonText = submitButton.innerHTML;
    submitButton.disabled = true;
    submitButton.innerHTML = `
      <span class="spinner-border spinner-border-sm me-2" aria-hidden="true"></span>
      Sending...
    `;
    showStatus('Sending your message...', 'info');

    try {
      const formData = new FormData(contactForm);

      // Combine country code and phone number into one field for Formspree
      const countryCode = document.getElementById('countryCode').value;
      const phoneNumber = document.getElementById('phone').value.trim();
      formData.set('phone', `${countryCode}${phoneNumber}`);

      const response = await fetch(contactForm.action, {
        method: 'POST',
        body: formData,
        headers: {
          'Accept': 'application/json'
        }
      });

      if (response.ok) {
        showStatus('✅ Thank you! Your message has been sent successfully. We will get back to you soon.', 'success');
        contactForm.reset();
        contactForm.classList.remove('was-validated');
      } else {
        let errorMessage = '❌ Sorry, there was a problem sending your message. Please try again.';

        try {
          const data = await response.json();

          if (data.errors && data.errors.length > 0) {
            errorMessage = '❌ ' + data.errors
              .map(error => error.message)
              .join('. ');
          }
        } catch (parseError) {
          // Keep the default error message
        }

        showStatus(errorMessage, 'error');
      }
    } catch (networkError) {
      showStatus('❌ Network error. Please check your internet connection and try again.', 'error');
    } finally {
      submitButton.disabled = false;
      submitButton.innerHTML = originalButtonText;
    }
  });

  function showStatus(message, type) {
    formStatus.textContent = message;
    formStatus.className = 'fw-semibold mb-0';

    if (type === 'success') {
      formStatus.classList.add('text-success');
    } else if (type === 'error') {
      formStatus.classList.add('text-danger');
    } else {
      formStatus.classList.add('text-muted');
    }
  }
 const params = new URLSearchParams(window.location.search);
    const selectedPackage = params.get("package");

    if (selectedPackage) {
      document.getElementById("package").value = selectedPackage;
      document.getElementById("subject").value = "Request a quote";
    }

    // Mobile menu
    const menuToggle = document.getElementById("menuToggle");
    const mainNav = document.getElementById("mainNav");

    menuToggle.addEventListener("click", () => {
      mainNav.classList.toggle("open");
      menuToggle.classList.toggle("active");
      menuToggle.textContent = mainNav.classList.contains("open") ? "✕" : "☰";
    });

    document.querySelectorAll("#mainNav a").forEach(link => {
      link.addEventListener("click", () => {
        mainNav.classList.remove("open");
        menuToggle.classList.remove("active");
        menuToggle.textContent = "☰";
      });
    });

    // Form submission through Formspree
    const form = document.getElementById("contactForm");
    const status = document.getElementById("formStatus");

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      status.textContent = "Sending your message...";
      status.style.color = "#0b5d51";

      try {
        const response = await fetch(form.action, {
          method: "POST",
          body: new FormData(form),
          headers: { Accept: "application/json" }
        });

        if (response.ok) {
          status.textContent = "Thank you! Your message has been sent. We will contact you soon.";
          form.reset();
        } else {
          status.textContent = "Sorry, something went wrong. Please try again or email us directly.";
          status.style.color = "#b3261e";
        }
      } catch (error) {
        status.textContent = "Network error. Please check your connection and try again.";
        status.style.color = "#b3261e";
      }
    });

    
      const menuToggle = document.getElementById("menuToggle");
    const mainNav = document.getElementById("mainNav");

    menuToggle.addEventListener("click", () => {
      mainNav.classList.toggle("open");
      menuToggle.classList.toggle("active");
      menuToggle.textContent = mainNav.classList.contains("open") ? "✕" : "☰";
    });

    document.querySelectorAll("#mainNav a").forEach(link => {
      link.addEventListener("click", () => {
        mainNav.classList.remove("open");
        menuToggle.classList.remove("active");
        menuToggle.textContent = "☰";
      });
    });

  // Autoplay every 6 seconds
  let reviewAutoplay = setInterval(() => {
    showReview(currentReview + 1);
  }, 6000);

  // Restart autoplay after manual navigation
  function restartReviewAutoplay() {
    clearInterval(reviewAutoplay);
    reviewAutoplay = setInterval(() => {
      showReview(currentReview + 1);
    }, 6000);
  }

  document.getElementById('prevReview').addEventListener('click', restartReviewAutoplay);
  document.getElementById('nextReview').addEventListener('click', restartReviewAutoplay);

  reviewDots.forEach(dot => {
    dot.addEventListener('click', restartReviewAutoplay);
  });

  // Pause when the user hovers over the carousel
  const reviewCarousel = document.querySelector('.review-carousel');

  reviewCarousel.addEventListener('mouseenter', () => clearInterval(reviewAutoplay));
  reviewCarousel.addEventListener('mouseleave', restartReviewAutoplay);